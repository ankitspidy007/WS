#!/bin/bash

exec python3 /usr/src/app/main_app.py &
exec python3 /usr/src/app/hidden_app.py